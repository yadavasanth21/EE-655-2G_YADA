const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

// Load existing devices into memory on application startup
let devices = [];
if (fs.existsSync('devices.json')) {
    devices = JSON.parse(fs.readFileSync('devices.json'));
}

// Function to log activities with timestamps
function logData(activity) {
    const timestamp = new Date().toISOString();
    fs.appendFileSync('logs.txt', `${timestamp}: ${activity}\n`);
}

// POST endpoint to register new devices
app.post('/register', (req, res) => {
    const { deviceId, deviceType } = req.body;
    if (!deviceId || !deviceType) {
        return res.status(400).send('Both deviceId and deviceType are required.');
    }

    devices.push({ deviceId, deviceType });
    fs.writeFileSync('devices.json', JSON.stringify(devices));
    logData(`Registered device - ID: ${deviceId}, Type: ${deviceType}`);
    res.status(201).send('Device registered successfully.');
});

// GET endpoint to display all registered devices
app.get('/show', (req, res) => {
    res.json(devices);
});

// POST endpoint to receive data from devices
app.post('/data', (req, res) => {
    const { deviceId, data } = req.body;
    if (!deviceId || !data) {
        return res.status(400).send('Both deviceId and data are required.');
    }

    // Check if the device already exists
    const existingDeviceIndex = devices.findIndex(device => device.deviceId === deviceId);
    if (existingDeviceIndex !== -1) {
        // Update existing device with new data
        devices[existingDeviceIndex].data = data;
    } else {
        // Add new device with received data
        devices.push({ deviceId, data });
    }

    // Update devices.json file
    fs.writeFileSync('devices.json', JSON.stringify(devices));
    
    logData(`Received data from device - ID: ${deviceId}, Data: ${JSON.stringify(data)}`);
    res.send('Data received successfully.');
});
// POST endpoint to send commands to devices
app.post('/command', (req, res) => {
    const { deviceId, command } = req.body;
    if (!deviceId || !command) {
        return res.status(400).send('Both deviceId and command are required.');
    }

    // Check if the device already exists
    const existingDeviceIndex = devices.findIndex(device => device.deviceId === deviceId);
    if (existingDeviceIndex !== -1) {
        // Update existing device with new command
        devices[existingDeviceIndex].command = command;
    } else {
        // Add new device with received command
        devices.push({ deviceId, command });
    }

    // Update devices.json file
    fs.writeFileSync('devices.json', JSON.stringify(devices));

    logData(`Sent command to device - ID: ${deviceId}, Command: ${command}`);
    res.send('Command sent successfully.');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
