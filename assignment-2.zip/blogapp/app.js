const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/blogDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const Post = mongoose.model('Post', {
  userName: String,
  title: String,
  content: String
});

// Create a new blog post
app.post('/posts', async (req, res) => {
  try {
    const { userName, title, content } = req.body;
    const post = new Post({ userName, title, content });
    await post.save();
    res.status(201).send(post);
  } catch (error) {
    console.log(error)
    res.status(400).send("Failed to fetch posts.");
  }
});

app.get('/posts', async (req, res) => {
    try {
      const posts = await Post.find();
      res.json(posts);
    } catch (error) {
        console.log(error)
      res.status(404).send("Failed to fetch posts.");
    }
  });

  app.get('/posts/content/:searchWord', async (req, res) => {
    try {
      const { searchWord } = req.params;
      const posts = await Post.find({ content: { $regex: searchWord, $options: 'i' } });
      res.send(posts);
    } catch (error) {
        console.log(error)
      res.status(404).send("Failed to fetch posts.");
    }
  });

  app.get('/posts/title/:searchWord', async (req, res) => {
    try {
      const { searchWord } = req.params;
      const posts = await Post.find({ title: { $regex: searchWord, $options: 'i' } });
      res.send(posts);
    } catch (error) {
        console.log(error)
      res.status(404).send("Failed to fetch posts.");
    }
  });

// Retrieve all posts by a specific username
app.get('/posts/:username', async (req, res) => {
  try {
    const posts = await Post.find({ userName: req.params.username });
    res.send(posts);
  } catch (error) {
    console.log(error)
    res.status(404).send("Failed to fetch posts.");
  }
});

// Delete all posts by a specific user
app.delete('/posts/user/:username', async (req, res) => {
  try {
    await Post.deleteMany({ userName: req.params.username });
    res.send({ message: 'Posts deleted successfully' });
  } catch (error) {
    console.log(error)
    res.status(404).send("Failed to fetch posts.");
  }
});

app.delete('/posts/content/:searchWord', async (req, res) => {
    try {
      const { searchWord } = req.params;
      await Post.deleteMany({ content: { $regex: searchWord, $options: 'i' } });
      res.send({ message: 'Posts deleted successfully' });
    } catch (error) {
        console.log(error)
      res.status(404).send("Failed to fetch posts.");
    }
  });


app.get('/posts/count/:userName', async (req, res) => {
    try {
      const { userName } = req.params;
      const count = await Post.countDocuments({ userName });
      res.send({ userName, count });
    } catch (error) {
        console.log(error)
      res.status(404).send("Failed to fetch posts.");
    }
  });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on port 3000" ));